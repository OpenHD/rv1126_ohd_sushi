package com.rockchip.gpadc.demo.rockx;

import android.graphics.Point;
import android.util.Log;

public class KeyPoints {
    private Point[] points;
    private int count;

    public KeyPoints(int count) {
        Log.d("RockX", "count="+count);
        this.count = count;
        this.points = new Point[count];
        for (int i = 0; i < count; i++) {
            this.points[i] = new Point(-1, -1);
        }
    }

    public void setPoint(int index, int x, int y) {
        Log.d("RockX", "index="+index+" x="+x+" y="+y);
        points[index].set(x, y);
    }

    public Point getPoint(int index) {
        if (index < count) {
            return points[index];
        } else {
            return null;
        }
    }
}
